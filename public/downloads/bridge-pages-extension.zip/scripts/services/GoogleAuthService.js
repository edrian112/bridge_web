/**
 * Google OAuth 인증 서비스
 * Chrome Identity API를 사용한 구글 로그인
 * BackendService와 연동하여 JWT 인증 수행
 */

import { ErrorHandler } from '../components/ErrorHandler.js';
import { BackendService } from './BackendService.js';

export class GoogleAuthService {
  // 웹 애플리케이션 OAuth 클라이언트 (계정 선택 지원)
  static WEB_CLIENT_ID = '572269599668-ghonlp56dl5cqcqp9j4gp47476rm9dd3.apps.googleusercontent.com';
  static REDIRECT_URI = 'https://jphaihacfbdnmfmlenneghohoieaohjp.chromiumapp.org/';

  constructor() {
    this.user = null;
    this.token = null;
    this.backendService = new BackendService();
  }

  /**
   * 구글 로그인 실행
   * launchWebAuthFlow를 사용하여 계정 선택 화면 표시
   * @returns {Promise<Object>} 사용자 정보 { email, name, picture }
   */
  async login() {
    try {
      // 기존 캐시된 토큰 제거
      await this.clearCachedToken();

      // BackendService 메모리 및 스토리지 초기화
      await this.backendService.clear();

      // 이전 사용자 데이터 완전 제거 (계정 전환 시 데이터 혼선 방지)
      await ErrorHandler.safeStorageRemove([
        'googleUser', 'googleToken', 'googleLoginTime',
        'planType', 'remainingUsage', 'planPurchaseDate',
        'settings'  // settings 객체도 제거 (내부에 캐시된 googleUser/planType 포함)
      ]);
      console.log('Cleared all previous user data before login');

      // OAuth URL 생성 (계정 선택 프롬프트 포함)
      const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
      authUrl.searchParams.set('client_id', GoogleAuthService.WEB_CLIENT_ID);
      authUrl.searchParams.set('redirect_uri', GoogleAuthService.REDIRECT_URI);
      authUrl.searchParams.set('response_type', 'token');
      authUrl.searchParams.set('scope', 'email profile');
      authUrl.searchParams.set('prompt', 'select_account');

      // launchWebAuthFlow로 계정 선택 화면 표시
      const responseUrl = await new Promise((resolve, reject) => {
        chrome.identity.launchWebAuthFlow(
          { url: authUrl.toString(), interactive: true },
          (response) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else if (!response) {
              reject(new Error('No response from auth flow'));
            } else {
              resolve(response);
            }
          }
        );
      });

      // URL에서 access_token 추출
      const token = this.extractTokenFromUrl(responseUrl);
      if (!token) {
        throw new Error('Failed to extract access token');
      }

      this.token = token;

      // 백엔드 인증 (Google Access Token → JWT)
      const backendAuth = await this.backendService.authenticateWithGoogle(token);
      console.log('Backend authentication successful:', backendAuth.user.email);

      // 백엔드에서 받은 사용자 정보 사용
      this.user = {
        email: backendAuth.user.email,
        name: backendAuth.user.name,
        picture: backendAuth.user.picture,
        id: backendAuth.user.id
      };

      // Chrome Storage에 저장
      await ErrorHandler.safeStorageSet({
        googleUser: this.user,
        googleToken: token,
        googleLoginTime: Date.now()
      });

      // 백엔드에서 플랜 정보 동기화
      await this.syncPlanFromBackend();

      console.log('Google login successful:', this.user.email);
      return this.user;

    } catch (error) {
      console.error('Google login failed:', error);
      throw error;
    }
  }

  /**
   * URL에서 access_token 추출
   * @param {string} url - 리디렉션된 URL
   * @returns {string|null} Access token
   */
  extractTokenFromUrl(url) {
    try {
      // URL fragment에서 access_token 추출 (예: #access_token=xxx&token_type=Bearer...)
      const hashParams = new URL(url).hash.substring(1);
      const params = new URLSearchParams(hashParams);
      return params.get('access_token');
    } catch (error) {
      console.error('Failed to extract token from URL:', error);
      return null;
    }
  }

  /**
   * 구글 로그아웃
   */
  async logout() {
    try {
      // 백엔드 로그아웃
      await this.backendService.logout();

      // Chrome Storage에서 제거 (사용자 정보 + 플랜 데이터 + settings 모두)
      await ErrorHandler.safeStorageRemove([
        'googleUser', 'googleToken', 'googleLoginTime',
        'planType', 'remainingUsage', 'planPurchaseDate',
        'backendToken', 'backendUser',
        'settings'  // settings 객체도 제거 (내부에 캐시된 데이터 포함)
      ]);

      // 토큰 revoke
      if (this.token) {
        await this.revokeToken(this.token);
      }

      this.user = null;
      this.token = null;

      console.log('Google logout successful');
      return true;

    } catch (error) {
      console.error('Google logout failed:', error);
      throw error;
    }
  }

  /**
   * 로그인 상태 확인
   * 중요: 자동 재인증(토큰 재발급)을 하지 않고, 저장된 backendToken으로만 복구
   * @returns {Promise<Object|null>} 로그인되어 있으면 사용자 정보, 아니면 null
   */
  async checkLoginStatus() {
    try {
      // 백엔드 서비스 초기화 (저장된 JWT 토큰 로드)
      await this.backendService.init();

      const result = await ErrorHandler.safeStorageGet(['googleUser', 'googleToken', 'googleLoginTime']);

      if (!result.googleUser || !result.googleToken) {
        return null;
      }

      // 토큰이 7일 이상 경과했으면 만료로 간주
      const loginTime = result.googleLoginTime || 0;
      const daysSinceLogin = (Date.now() - loginTime) / (1000 * 60 * 60 * 24);

      if (daysSinceLogin > 7) {
        console.log('Token expired, logging out');
        await this.logout();
        return null;
      }

      // 백엔드 JWT 토큰이 있으면 그것만으로 세션 복구
      // Google 토큰 유효성 검증은 백엔드 토큰이 없을 때만 수행
      if (this.backendService.isAuthenticated()) {
        // 백엔드 사용자와 저장된 Google 사용자 이메일 일치 확인 (계정 섞임 방지)
        const backendUser = this.backendService.getCurrentUser();
        if (backendUser && backendUser.email !== result.googleUser.email) {
          console.error('Account mismatch detected! Backend:', backendUser.email, 'Stored:', result.googleUser.email);
          await this.logout();
          return null;
        }

        // 백엔드에서 최신 플랜 정보 동기화
        await this.syncPlanFromBackend();

        this.user = result.googleUser;
        this.token = result.googleToken;
        return this.user;
      }

      // 백엔드 토큰이 없으면 Google 토큰 유효성 검증
      const isValid = await this.validateToken(result.googleToken);
      if (!isValid) {
        console.log('Google token invalid, logging out');
        await this.logout();
        return null;
      }

      // Google 토큰으로 백엔드 재인증 시도
      // 중요: 재인증 전 토큰의 실제 이메일 확인
      try {
        const tokenUserInfo = await this.getUserInfo(result.googleToken);

        // 토큰 이메일 vs 저장된 사용자 이메일 비교
        if (tokenUserInfo.email !== result.googleUser.email) {
          console.error('Token email mismatch! Token:', tokenUserInfo.email, 'Stored:', result.googleUser.email);
          // 토큰 제거하고 로그아웃 - 사용자가 다시 로그인해야 함
          await this.clearCachedToken();
          await this.logout();
          return null;
        }

        // 이메일 일치 확인 후 백엔드 인증
        console.log('Re-authenticating with verified Google token...');
        await this.backendService.authenticateWithGoogle(result.googleToken);
      } catch (error) {
        console.error('Backend re-authentication failed:', error);
        await this.logout();
        return null;
      }

      // 백엔드에서 최신 플랜 정보 가져와서 로컬 스토리지 동기화
      await this.syncPlanFromBackend();

      this.user = result.googleUser;
      this.token = result.googleToken;

      return this.user;

    } catch (error) {
      console.error('Failed to check login status:', error);
      return null;
    }
  }

  /**
   * Chrome Identity API로 OAuth 토큰 획득
   * @param {boolean} interactive - 사용자 상호작용 허용 여부
   * @returns {Promise<string>} Access token
   */
  async getAuthToken(interactive = false) {
    return new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({ interactive }, (token) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(token);
        }
      });
    });
  }

  /**
   * 토큰으로 사용자 정보 가져오기
   * @param {string} token - Access token
   * @returns {Promise<Object>} 사용자 정보
   */
  async getUserInfo(token) {
    const response = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    if (!response.ok) {
      throw new Error('Failed to get user info');
    }

    return await response.json();
  }

  /**
   * 토큰 유효성 검증
   * @param {string} token - Access token
   * @returns {Promise<boolean>} 유효하면 true
   */
  async validateToken(token) {
    try {
      const response = await fetch(`https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=${token}`);
      return response.ok;
    } catch (error) {
      console.error('Token validation failed:', error);
      return false;
    }
  }

  /**
   * 토큰 revoke
   * @param {string} token - Access token
   */
  async revokeToken(token) {
    return new Promise((resolve, reject) => {
      chrome.identity.removeCachedAuthToken({ token }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          // Google에도 revoke 요청
          fetch(`https://accounts.google.com/o/oauth2/revoke?token=${token}`)
            .then(() => resolve())
            .catch(reject);
        }
      });
    });
  }

  /**
   * 캐시된 토큰 제거
   * 중요: getAuthToken(interactive:false)를 사용하지 않음 - 잘못된 계정 토큰 반환 방지
   * 저장된 토큰만 제거하고, 새로운 토큰을 가져오지 않음
   */
  async clearCachedToken() {
    return new Promise(async (resolve) => {
      // 현재 메모리에 저장된 토큰 제거
      if (this.token) {
        chrome.identity.removeCachedAuthToken({ token: this.token }, () => {
          console.log('Cleared cached token from memory');
          this.token = null;
          resolve();
        });
      } else {
        // 메모리에 토큰이 없으면 Storage에서 확인
        try {
          const result = await ErrorHandler.safeStorageGet(['googleToken']);
          if (result.googleToken) {
            chrome.identity.removeCachedAuthToken({ token: result.googleToken }, () => {
              console.log('Cleared cached token from storage');
              resolve();
            });
          } else {
            resolve();
          }
        } catch (error) {
          console.log('No token to clear');
          resolve();
        }
      }
    });
  }

  /**
   * 현재 로그인된 사용자 정보 가져오기
   * @returns {Object|null} 사용자 정보
   */
  getCurrentUser() {
    return this.user;
  }

  /**
   * 백엔드에서 플랜 정보를 가져와서 로컬 스토리지 동기화
   */
  async syncPlanFromBackend() {
    try {
      if (!this.backendService.isAuthenticated()) {
        console.log('Cannot sync plan: not authenticated');
        return null;
      }

      const planData = await this.backendService.getPlan('notes');
      console.log('Plan data from backend:', planData);

      if (planData && planData.subscription) {
        const { planId, remaining } = planData.subscription;

        // 로컬 스토리지 업데이트
        await ErrorHandler.safeStorageSet({
          planType: planId,
          remainingUsage: remaining
        });

        console.log(`Plan synced from backend: ${planId}, remaining: ${remaining}`);

        // 플랜 업데이트 이벤트 발생 (다른 컴포넌트에서 리슨)
        window.dispatchEvent(new CustomEvent('planUpdated', {
          detail: { planType: planId, remainingUsage: remaining }
        }));

        return { planType: planId, remainingUsage: remaining };
      }
      return null;
    } catch (error) {
      console.error('Failed to sync plan from backend:', error);
      // 실패해도 기존 로컬 데이터로 계속 진행
      return null;
    }
  }

  /**
   * 현재 토큰 가져오기
   * @returns {string|null} Access token
   */
  getToken() {
    return this.token;
  }

  /**
   * 백엔드 서비스 가져오기
   * 플랜 조회, 사용량 확인 등에 사용
   * @returns {BackendService}
   */
  getBackendService() {
    return this.backendService;
  }
}
