/**
 * ResultArea Component for BRIDGE Pages
 * 캡처된 텍스트를 표시하고 웹 페이지로 리다이렉트
 */
import { i18n } from '../i18n/i18n.js';

export class ResultArea {
  constructor(toast = null, errorHandler = null, settings = null, apiService = null, cacheService = null, historyService = null) {
    // DOM 요소들
    this.resultArea = document.getElementById("resultArea");
    this.emptyState = document.getElementById("emptyState");
    this.resultContent = document.getElementById("resultContent");
    this.originalText = document.getElementById("originalText");
    this.loadingState = document.getElementById("loadingState");

    // 버튼들
    this.copyOriginalBtn = document.getElementById("copyOriginalBtn");
    this.goToEditorBtn = document.getElementById("goToEditorBtn");

    // 서비스들
    this.toast = toast;
    this.errorHandler = errorHandler;
    this.settings = settings;
    this.historyService = historyService;

    // 상태
    this.capturedText = "";

    // bridge_web URL (개발/프로덕션 환경 분기)
    this.bridgeWebUrl = this.getBridgeWebUrl();

    this.init();
  }

  /**
   * bridge_web URL 결정 (설정에서 가져오기)
   */
  getBridgeWebUrl() {
    // 설정에서 editorUrl 가져오기
    if (this.settings && this.settings.currentSettings.editorUrl) {
      return this.settings.currentSettings.editorUrl;
    }
    // 기본값: localhost:3000
    return 'http://localhost:3000';
  }

  init() {
    // 원문 복사 버튼
    if (this.copyOriginalBtn) {
      this.copyOriginalBtn.addEventListener("click", () => {
        this.copyOriginalText();
      });
    }

    // 에디터로 이동 버튼
    if (this.goToEditorBtn) {
      this.goToEditorBtn.addEventListener("click", () => {
        this.goToEditor();
      });
    }

    // 히스토리 항목 선택 이벤트 리스너
    document.addEventListener('historyItemSelected', (e) => {
      this.loadFromHistory(e.detail);
    });
  }

  /**
   * 캡처된 텍스트 표시 및 자동 리다이렉트 옵션
   */
  async show(text) {
    this.capturedText = text;

    // 빈 상태 숨김
    if (this.emptyState) {
      this.emptyState.style.display = "none";
    }

    // 결과 콘텐츠 표시
    if (this.resultContent) {
      this.resultContent.style.display = "block";
    }

    // 원문 표시
    if (this.originalText) {
      this.originalText.textContent = text;
    }

    // 원본 복사 버튼 활성화
    if (this.copyOriginalBtn) {
      this.copyOriginalBtn.disabled = false;
    }

    // 에디터 버튼 활성화
    if (this.goToEditorBtn) {
      this.goToEditorBtn.disabled = false;
    }

    // 히스토리에 저장
    await this.saveToHistory();

    // 토스트 메시지
    if (this.toast) {
      this.toast.success(i18n.t("toast.captureComplete"));
    }

    // 설정에 따라 자동 리다이렉트 (옵션)
    if (this.settings && this.settings.currentSettings.autoRedirect === true) {
      await this.delay(500);
      this.goToEditor();
    }
  }

  /**
   * bridge_web 에디터 페이지로 이동
   */
  async goToEditor() {
    if (!this.capturedText) {
      if (this.toast) {
        this.toast.error(i18n.t("toast.noTextToEdit"));
      }
      return;
    }

    try {
      // 로딩 상태 표시
      this.showLoading();

      // 텍스트를 base64로 인코딩하여 URL hash로 전달
      const encodedText = btoa(unescape(encodeURIComponent(this.capturedText)));

      // 설정에서 최신 editorUrl 가져오기
      const baseUrl = this.getBridgeWebUrl();
      const editorUrl = `${baseUrl}/pages/create#text=${encodedText}`;

      // 새 탭에서 bridge_web 에디터 열기
      chrome.tabs.create({ url: editorUrl }, (tab) => {
        this.hideLoading();

        if (this.toast) {
          this.toast.success(i18n.t("toast.openingEditor"));
        }
      });

    } catch (error) {
      this.hideLoading();
      console.error("에디터 열기 실패:", error);

      if (this.errorHandler) {
        this.errorHandler.handle(error, "goToEditor", {
          customMessage: "에디터를 열 수 없습니다",
        });
      }
    }
  }

  /**
   * 원문 복사
   */
  async copyOriginalText() {
    try {
      if (!this.capturedText) {
        if (this.toast) {
          this.toast.error(i18n.t("toast.noOriginalText"));
        }
        return;
      }

      await navigator.clipboard.writeText(this.capturedText);

      if (this.toast) {
        this.toast.success(i18n.t("toast.originalCopied"));
      }
    } catch (error) {
      console.error("원문 복사 실패:", error);
      if (this.errorHandler) {
        this.errorHandler.handle(error, "copyOriginalText", {
          customMessage: "원문 복사에 실패했습니다",
        });
      }
    }
  }

  /**
   * 히스토리에 결과 저장
   */
  async saveToHistory() {
    if (!this.historyService) return;

    try {
      await this.historyService.addToHistory({
        originalText: this.capturedText,
        processedText: "", // Pages에서는 웹에서 처리
        template: "pages",
        tone: "",
        metadata: {
          source: "bridge_pages_extension"
        }
      });

      // 히스토리 새로고침 이벤트 발생
      const event = new CustomEvent('historyUpdated');
      document.dispatchEvent(event);

      console.log('Saved to history');
    } catch (error) {
      console.error('Failed to save to history:', error);
    }
  }

  /**
   * 히스토리에서 항목 불러오기
   */
  loadFromHistory(item) {
    console.log('Loading from history:', item);

    this.capturedText = item.originalText;

    // 빈 상태 숨기기
    if (this.emptyState) {
      this.emptyState.style.display = 'none';
    }
    if (this.resultContent) {
      this.resultContent.style.display = 'block';
    }

    // 원본 텍스트 표시
    if (this.originalText) {
      this.originalText.textContent = this.capturedText;
    }

    // 버튼 활성화
    if (this.copyOriginalBtn) {
      this.copyOriginalBtn.disabled = false;
    }
    if (this.goToEditorBtn) {
      this.goToEditorBtn.disabled = false;
    }

    if (this.toast) {
      this.toast.success(i18n.t('toast.historyLoaded'));
    }
  }

  /**
   * 로딩 표시
   */
  showLoading() {
    if (this.loadingState) {
      this.loadingState.style.display = "flex";
    }
  }

  /**
   * 로딩 숨김
   */
  hideLoading() {
    if (this.loadingState) {
      this.loadingState.style.display = "none";
    }
  }

  /**
   * 빈 상태 표시
   */
  showEmpty() {
    if (this.emptyState) {
      this.emptyState.style.display = "flex";
    }
    if (this.resultContent) {
      this.resultContent.style.display = "none";
    }
    this.capturedText = "";
  }

  /**
   * Delay 유틸리티
   */
  delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}
