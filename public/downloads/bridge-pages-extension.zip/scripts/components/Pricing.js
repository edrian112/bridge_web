/**
 * Pricing Component
 * 과금 플랜 및 구매 페이지
 */

import { ErrorHandler } from "./ErrorHandler.js";
import { i18n } from "../i18n/i18n.js";

// ============================================
// 🔧 베타/출시 설정 - 결제 시스템 연동 시 수정
// ============================================
const BETA_MODE = true; // false로 변경하면 결제 페이지 연동 활성화
const BRIDGE_WEB_URL = "https://bridge-web.vercel.app"; // 배포 후 실제 도메인으로 변경
// ============================================

export class Pricing {
  constructor(toast = null, errorHandler = null, settings = null) {
    this.pricingContainer = document.getElementById("pricingTab");
    this.toast = toast;
    this.errorHandler = errorHandler;
    this.settings = settings; // Settings 컴포넌트 (백엔드 연동용)
    this.i18n = i18n;

    // 플랜 정보 (기본 데이터만 저장, 텍스트는 렌더링 시 i18n으로 처리)
    this.plansData = [
      {
        id: "free",
        name: "Free",
        price: 0,
        periodKey: "pricing.period.forever",
        usageCount: 5,
        historyCount: 3,
        hasTones: true,
        hasCustomModel: false,
        hasBridgePages: false,
        badge: null,
        current: false,
      },
      {
        id: "basic30",
        name: "Basic 30",
        price: 4900,
        periodKey: "30",
        periodUnit: "pricing.period.times",
        usageCount: 30,
        historyCount: 10,
        hasTones: true,
        hasCustomModel: false,
        hasBridgePages: false,
        badge: null,
        recommended: false,
      },
      {
        id: "standard70",
        name: "Standard 70",
        price: 9900,
        periodKey: "70",
        periodUnit: "pricing.period.times",
        usageCount: 70,
        historyCount: 10,
        hasTones: true,
        hasCustomModel: true,
        hasBridgePages: false,
        badge: "pricing.badge.popular",
        recommended: true,
      },
      {
        id: "max",
        name: "MAX",
        price: 29000,
        periodKey: "pricing.period.month",
        usageCount: -1, // unlimited
        historyCount: -1, // unlimited
        hasTones: true,
        hasCustomModel: true,
        hasBridgePages: true,
        badge: null,
      },
    ];

    this.init();
  }

  async init() {
    // 현재 플랜 정보 불러오기
    await this.loadCurrentPlan();

    // 렌더링
    this.render();

    // 언어 변경 감지 (언어 변경 시 Pricing UI 재렌더링)
    this.i18n.onLanguageChange((lang) => {
      this.render();
    });

    // 플랜 업데이트 이벤트 리스너 (백엔드 동기화 후 자동 반영)
    window.addEventListener('planUpdated', async (event) => {
      console.log('Pricing: planUpdated event received', event.detail);
      if (event.detail && event.detail.planType) {
        this.currentPlan = event.detail.planType;
        this.render();
      }
    });
  }

  /**
   * 현재 사용자 플랜 불러오기
   */
  async loadCurrentPlan() {
    try {
      // processDemoPayment()에서 저장한 planType 키 읽기
      const result = await ErrorHandler.safeStorageGet(["planType"]);

      if (result.planType) {
        this.currentPlan = result.planType;
      } else {
        this.currentPlan = "free";
      }

      console.log("Current plan:", this.currentPlan);
    } catch (error) {
      console.error("Failed to load user plan:", error);
      this.currentPlan = "free";
    }
  }

  /**
   * 과금 페이지 렌더링
   */
  render() {
    if (!this.pricingContainer) return;

    this.pricingContainer.innerHTML = `
      <div class="pricing-wrapper">
        <div class="pricing-plans">
          ${this.plansData.map((plan) => this.renderPlanCard(plan)).join("")}
        </div>

        <div class="pricing-faq">
          <h3>${this.i18n.t("pricing.faq.title")}</h3>

          <div class="faq-item">
            <div class="faq-question">${this.i18n.t("pricing.faq.q1")}</div>
            <div class="faq-answer">${this.i18n.t("pricing.faq.a1")}</div>
          </div>

          <div class="faq-item">
            <div class="faq-question">${this.i18n.t("pricing.faq.q2")}</div>
            <div class="faq-answer">${this.i18n.t("pricing.faq.a2")}</div>
          </div>

          <div class="faq-item">
            <div class="faq-question">${this.i18n.t("pricing.faq.q3")}</div>
            <div class="faq-answer">${this.i18n.t("pricing.faq.a3")}</div>
          </div>

          <div class="faq-item">
            <div class="faq-question">${this.i18n.t("pricing.faq.q4")}</div>
            <div class="faq-answer">${this.i18n.t("pricing.faq.a4")}</div>
          </div>

          <div class="faq-item">
            <div class="faq-question">${this.i18n.t("pricing.faq.q5")}</div>
            <div class="faq-answer">${this.i18n.t("pricing.faq.a5")}</div>
          </div>
        </div>
      </div>
    `;

    // 이벤트 리스너 등록
    this.attachEventListeners();
  }

  /**
   * 플랜 카드 렌더링
   */
  renderPlanCard(plan) {
    const isCurrent = plan.id === this.currentPlan;
    const badgeHtml = plan.badge
      ? `<span class="plan-badge ${
          plan.recommended ? "recommended" : "current"
        }">${this.i18n.t(plan.badge)}</span>`
      : "";

    // Period 텍스트 생성
    const periodText = plan.periodUnit
      ? `${plan.periodKey}${this.i18n.t(plan.periodUnit)}`
      : this.i18n.t(plan.periodKey);

    // Features 배열 생성
    const features = [
      {
        text: plan.usageCount === -1
          ? this.i18n.t("settings.unlimited")
          : `${this.i18n.t("pricing.feature.usage")} ${plan.usageCount}${this.i18n.t("pricing.period.times")}`,
        available: true
      },
      {
        text: plan.historyCount === -1
          ? this.i18n.t("pricing.feature.historyUnlimited")
          : this.i18n.t("pricing.feature.history").replace("{count}", plan.historyCount),
        available: true
      },
      {
        text: this.i18n.t("pricing.feature.tones"),
        available: plan.hasTones
      },
      {
        text: this.i18n.t("pricing.feature.customModel"),
        available: plan.hasCustomModel
      },
      {
        text: this.i18n.t("pricing.feature.bridgePages"),
        available: plan.hasBridgePages
      }
    ];

    return `
      <div class="plan-card ${plan.recommended ? "recommended" : ""} ${
      isCurrent ? "current" : ""
    }">
        ${badgeHtml}

        <div class="plan-header">
          <h3 class="plan-name">${plan.name}</h3>
          <div class="plan-price">
            ${
              plan.price === 0
                ? `<span class="price-amount">${this.i18n.t("pricing.free")}</span>`
                : `<span class="price-amount">₩${plan.price.toLocaleString()}</span><span class="price-period">/${periodText}</span>`
            }
          </div>
        </div>

        <div class="plan-features">
          ${features
            .map(
              (feature) => `
            <div class="feature-item ${feature.available ? "" : "unavailable"}">
              <span class="feature-icon">${feature.available ? "✓" : "✕"}</span>
              <span class="feature-text">${feature.text}</span>
            </div>
          `
            )
            .join("")}
        </div>

        <button
          class="plan-button ${isCurrent ? "current-plan" : ""}"
          data-plan="${plan.id}"
          ${isCurrent ? "disabled" : ""}
        >
          ${
            isCurrent
              ? this.i18n.t("pricing.button.current")
              : plan.price === 0
              ? this.i18n.t("pricing.button.startFree")
              : this.i18n.t("pricing.button.purchase")
          }
        </button>
      </div>
    `;
  }

  /**
   * 이벤트 리스너 등록
   */
  attachEventListeners() {
    const planButtons = this.pricingContainer.querySelectorAll(".plan-button");

    planButtons.forEach((button) => {
      button.addEventListener("click", (e) => {
        const planId = button.getAttribute("data-plan");
        this.handlePlanSelection(planId);
      });
    });
  }

  /**
   * 플랜 선택 처리
   */
  async handlePlanSelection(planId) {
    const plan = this.plansData.find((p) => p.id === planId);

    if (!plan) return;

    // 무료 플랜인 경우
    if (plan.price === 0) {
      await this.switchToFreePlan();
      return;
    }

    // 유료 플랜인 경우 - 결제 프로세스
    this.initiatePayment(plan);
  }

  /**
   * 무료 플랜으로 전환 (백엔드 연동)
   * 베타 기간: 플랜 변경 비활성화
   */
  async switchToFreePlan() {
    // 베타 기간: 플랜 변경 불가
    if (this.toast) {
      this.toast.info(this.i18n.t("pricing.toast.paidPlanNotAvailable") || "플랜 변경은 현재 준비 중입니다. 베타 기간 동안 무료로 이용해 주세요!");
    }
    return;

    // === 아래 코드는 베타 종료 후 활성화 ===
    /*
    try {
      // 백엔드 API 호출 - remaining은 백엔드에서만 관리
      if (this.settings && this.settings.googleAuthService) {
        const backendService = this.settings.googleAuthService.getBackendService();
        if (backendService.isAuthenticated()) {
          try {
            console.log('Switching to free plan via backend');
            const result = await backendService.updatePlan('free', 'notes');
            const remaining = result.subscription.remaining;
            console.log('Backend free plan result:', result);

            // 백엔드 응답으로만 로컬 업데이트 (표시용 캐시)
            await ErrorHandler.safeStorageSet({
              planType: "free",
              remainingUsage: remaining
            });

            this.currentPlan = "free";

            if (this.toast) {
              this.toast.success(this.i18n.t("pricing.toast.switchedToFree"));
            }

            // Settings 컴포넌트에 플랜 변경 알림
            window.dispatchEvent(new CustomEvent('planUpdated', {
              detail: { planType: 'free', remainingUsage: remaining }
            }));

            this.render();
          } catch (error) {
            console.error('Backend free plan switch failed:', error);
            if (this.toast) {
              this.toast.error('플랜 변경에 실패했습니다. 다시 시도해주세요.');
            }
          }
        } else {
          if (this.toast) {
            this.toast.warning('플랜 변경을 위해 먼저 로그인해주세요.');
          }
        }
      }
    } catch (error) {
      if (this.errorHandler) {
        this.errorHandler.handle(error, "switchToFreePlan");
      }
    }
    */
  }

  /**
   * 결제 프로세스 시작
   * BETA_MODE: 베타 안내 메시지 표시
   * 정식 출시: 웹사이트 pricing 페이지로 이동
   */
  initiatePayment(plan) {
    // 🔒 베타 기간: 유료 플랜 구매 불가 안내
    if (BETA_MODE) {
      if (this.toast) {
        this.toast.info(this.i18n.t("pricing.toast.betaFreeOnly") || "베타 기간 동안 무료로 이용해 주세요! 정식 출시 후 유료 플랜을 이용하실 수 있습니다.");
      }
      return;
    }

    // 🚀 정식 출시: 웹사이트 pricing 페이지로 이동 (새 탭)
    const pricingUrl = `${BRIDGE_WEB_URL}/pricing?plan=${plan.id}&product=notes`;

    if (this.toast) {
      this.toast.info(this.i18n.t("pricing.toast.redirecting") || "결제 페이지로 이동합니다...");
    }

    // Chrome extension에서 새 탭 열기
    if (chrome && chrome.tabs) {
      chrome.tabs.create({ url: pricingUrl });
    } else {
      // 폴백: 일반 window.open
      window.open(pricingUrl, "_blank");
    }
  }

  /**
   * 플랜 구매 처리 (백엔드 연동)
   */
  async processDemoPayment(plan) {
    try {
      // Google 로그인 확인
      const googleUser = await ErrorHandler.safeStorageGet(['googleUser']);
      if (!googleUser.googleUser) {
        if (this.toast) {
          this.toast.warning('플랜 구매를 위해 먼저 Google 로그인이 필요합니다.');
        }
        return;
      }

      // 로딩 표시
      if (this.toast) {
        this.toast.info(this.i18n.t("pricing.toast.processing"));
      }

      let remaining = plan.usageCount;

      // 백엔드 API 호출
      if (this.settings && this.settings.googleAuthService) {
        const backendService = this.settings.googleAuthService.getBackendService();
        if (backendService.isAuthenticated()) {
          try {
            console.log('Updating plan via backend:', plan.id);
            const result = await backendService.updatePlan(plan.id, 'notes');
            remaining = result.subscription.remaining;
            console.log('Backend plan update result:', result);
          } catch (error) {
            console.error('Backend plan update failed:', error);
            // 백엔드 실패 시 로컬에만 저장 (fallback)
          }
        }
      }

      // 로컬 스토리지 업데이트
      const saved = await ErrorHandler.safeStorageSet({
        planType: plan.id,
        remainingUsage: remaining,
        planPurchaseDate: Date.now(),
      });

      if (saved) {
        this.currentPlan = plan.id;

        if (this.toast) {
          this.toast.success(
            this.i18n.t("pricing.toast.purchaseSuccess").replace("{planName}", plan.name) + " 🎉"
          );
        }

        // Settings 컴포넌트에 플랜 변경 알림
        window.dispatchEvent(new CustomEvent('planUpdated', {
          detail: { planType: plan.id, remainingUsage: remaining }
        }));

        // 페이지 다시 렌더링
        this.render();
      }
    } catch (error) {
      if (this.errorHandler) {
        this.errorHandler.handle(error, "processDemoPayment", {
          customMessage: this.i18n.t("pricing.error.payment"),
        });
      }
    }
  }

  /**
   * 현재 플랜 정보 가져오기
   */
  getCurrentPlan() {
    return this.currentPlan;
  }

  /**
   * 플랜 제한 확인
   */
  async checkLimit(action) {
    // 무료 플랜의 제한 확인
    if (this.currentPlan === "free") {
      const result = await ErrorHandler.safeStorageGet(["usageCount"]);
      const usageCount = result.usageCount || 0;

      if (action === "capture" && usageCount >= 5) {
        if (this.toast) {
          this.toast.error(this.i18n.t("pricing.toast.limitReached"));
        }
        return false;
      }
    }

    return true;
  }

  /**
   * 사용 횟수 증가
   */
  async incrementUsage() {
    try {
      const result = await ErrorHandler.safeStorageGet([
        "usageCount",
        "usageMonth",
      ]);
      let usageCount = result.usageCount || 0;
      let usageMonth = result.usageMonth || new Date().getMonth();

      const currentMonth = new Date().getMonth();

      // 월이 바뀌면 사용 횟수 초기화
      if (currentMonth !== usageMonth) {
        usageCount = 0;
        usageMonth = currentMonth;
      }

      usageCount++;

      await ErrorHandler.safeStorageSet({
        usageCount,
        usageMonth,
      });

      console.log(`Usage count: ${usageCount}`);
    } catch (error) {
      console.error("Failed to increment usage:", error);
    }
  }
}
