/**
 * BRIDGE Pages - 번역 파일
 * UI 텍스트의 한국어/영어 번역
 */

export const translations = {
  ko: {
    // 헤더
    'header.title': 'BRIDGE Pages',
    'header.subtitle': 'AI 대화를 블로그 콘텐츠로',

    // 메인 버튼
    'button.startCapture': '범위 선택 시작',

    // 빈 상태
    'empty.title': '아직 캡처된 내용이 없습니다',
    'empty.description': '위의 "범위 선택 시작" 버튼을 눌러\nAI 대화 내용을 캡처해보세요',
    'empty.hint': '캡처 후 블로그 에디터에서 콘텐츠를 확장하세요',

    // 결과 영역
    'result.copy': '복사',
    'result.goToEditor': '에디터로 이동',
    'result.capturedText': '캡처된 텍스트',
    'result.loading': '에디터를 여는 중...',

    // 탭
    'tab.main': 'BRIDGE Pages',
    'tab.history': '히스토리',
    'tab.pricing': '요금제',

    // 히스토리
    'history.clearAll': '전체삭제',
    'history.empty': '아직 저장된 캡처가 없습니다',

    // 푸터
    'footer.settings': '설정',

    // 설정 모달
    'settings.title': '설정',
    'settings.googleLogin': 'Google로 로그인',
    'settings.googleLogout': 'Google에서 로그아웃',
    'settings.language': '언어',
    'settings.plan': '사용 플랜',
    'settings.remaining': '잔여량',
    'settings.theme': '테마',
    'settings.themeSystem': '시스템 설정 따라가기',
    'settings.themeLight': '라이트 모드',
    'settings.themeDark': '다크 모드',
    'settings.autoRedirect': '자동 에디터 열기',
    'settings.advanced': '고급 설정',
    'settings.defaultClickMode': '기본 클릭 모드',
    'settings.defaultClickModeText': '텍스트 위치부터 (Shift=전체)',
    'settings.defaultClickModeDiv': '전체 대화블록 (Shift=텍스트)',
    'settings.editorUrl': '에디터 URL',
    'settings.editorUrlDesc': 'BRIDGE Pages 에디터 주소',
    'settings.info': '정보',
    'settings.infoDesc': 'AI 대화를 SEO 최적화된 블로그 콘텐츠로 확장',
    'settings.supportedSites': '지원 사이트:',
    'settings.copyright': 'Product by BRIDGE',
    'settings.reset': '재설정',
    'settings.save': '저장',
    'settings.unlimited': '무제한',

    // 토스트 메시지
    'toast.settingsSaved': '설정이 저장되었습니다!',
    'toast.settingsReset': '설정이 기본값으로 재설정되었습니다!',
    'toast.copied': '클립보드에 복사되었습니다!',
    'toast.historyLoaded': '히스토리에서 불러왔습니다',
    'toast.googleLoginSoon': '구글 로그인 기능은 곧 제공될 예정입니다!',
    'toast.captureComplete': '캡처가 완료되었습니다!',
    'toast.selectionModeActivated': '범위 선택 모드가 활성화되었습니다!',
    'toast.noOriginalText': '복사할 원문이 없습니다',
    'toast.originalCopied': '원문이 클립보드에 복사되었습니다!',
    'toast.noTextToEdit': '에디터에서 편집할 텍스트가 없습니다',
    'toast.openingEditor': '에디터를 열고 있습니다...',
    'toast.historyLoadFailed': '히스토리 로딩 실패',
    'toast.historyItemDeleted': '히스토리 항목 삭제됨',
    'toast.historyDeleteFailed': '삭제 실패',
    'toast.historyAllDeleted': '히스토리 전체 삭제됨',
    'toast.noUsageRemaining': '사용 가능한 횟수가 없습니다. 플랜을 구매해주세요.',
    'toast.usageRemaining': '남은 사용 횟수: {count}회',
    'toast.usageExhausted': '사용 가능한 횟수를 모두 소진했습니다.',
    'toast.googleLoginProcessing': 'Google 로그인 중...',
    'toast.googleLoginSuccess': '{name}님, 환영합니다!',
    'toast.googleLoginFailed': 'Google 로그인에 실패했습니다.',
    'toast.googleLogoutSuccess': 'Google 로그아웃 완료',

    // 확인 메시지
    'confirm.resetSettings': '모든 설정을 기본값으로 재설정하시겠습니까?',
    'confirm.googleLogout': '{email} 계정에서 로그아웃하시겠습니까?',

    // 메시지 역할 라벨
    'role.user': '사용자',
    'role.ai': 'AI',

    // 플랜/가격
    'pricing.free': '무료',
    'pricing.period.forever': '영구',
    'pricing.period.times': '회',
    'pricing.period.month': '월',
    'pricing.badge.popular': '인기',
    'pricing.feature.usage': '사용횟수',
    'pricing.feature.history': '히스토리 {count}개 저장',
    'pricing.feature.historyUnlimited': '히스토리 무제한 (1개월 보관)',
    'pricing.feature.blogExpansion': 'AI 블로그 확장 기능',
    'pricing.feature.seoOptimization': 'SEO 최적화',
    'pricing.feature.autoPublish': '블로그 자동 발행',
    'pricing.button.current': '현재 플랜',
    'pricing.button.startFree': '무료로 시작',
    'pricing.button.purchase': '구매하기',
    'pricing.faq.title': '자주 묻는 질문',
    'pricing.faq.q1': '🎫 회권 플랜은 어떻게 사용하나요?',
    'pricing.faq.a1': 'Basic 30과 Standard 70은 구매 시 사용 횟수가 충전되며, 소진 시까지 사용 가능합니다. 무제한 횟수 사용을 원하시면 MAX 플랜을 선택해주세요.',
    'pricing.faq.q2': '⏱️ MAX 플랜은 언제까지 사용할 수 있나요?',
    'pricing.faq.a2': 'MAX 플랜은 월 구독제로, 매월 자동 갱신됩니다. 언제든지 구독을 취소할 수 있으며, 취소 시 다음 결제일까지 사용 가능합니다.',
    'pricing.faq.q3': '💳 결제 수단은 무엇이 있나요?',
    'pricing.faq.a3': '신용카드, 체크카드, 계좌이체를 지원합니다. 안전한 결제를 위해 PG사를 통해 처리됩니다.',
    'pricing.faq.q4': '🔄 플랜을 변경할 수 있나요?',
    'pricing.faq.a4': '네, 언제든지 상위 플랜으로 업그레이드 가능합니다. 기존 잔여 횟수는 유지되며, 추가 기능을 즉시 사용할 수 있습니다.',
    'pricing.faq.q5': '💰 환불 정책은 어떻게 되나요?',
    'pricing.faq.a5': '구매 후 7일 이내, 사용 전이라면 전액 환불이 가능합니다. 사용 후에는 잔여 횟수에 비례하여 환불해드립니다.',
    'pricing.toast.comingSoon': '플랜 구매 기능은 곧 제공될 예정입니다!',
    'pricing.toast.confirmPurchase': '정말로 {planName} 플랜을 구매하시겠습니까?',
    'pricing.toast.alreadyCurrent': '이미 현재 플랜입니다!',
    'pricing.toast.purchaseSuccess': '{planName} 플랜 구매가 완료되었습니다!',
    'pricing.toast.switchedToFree': '무료 플랜으로 전환되었습니다!',
    'pricing.toast.processing': '결제 처리 중...',
    'pricing.toast.limitReached': '사용 횟수가 모두 소진되었습니다. 요금제 탭에서 충전하세요!',
    'pricing.toast.paidPlanNotAvailable': '유료 요금제는 현재 준비 중입니다. 베타 기간 동안 무료로 이용해 주세요!',
    'pricing.toast.betaFreeOnly': '🎉 베타 기간 동안 무료로 이용해 주세요! 정식 출시 후 유료 플랜을 이용하실 수 있습니다.',
    'pricing.toast.redirecting': '결제 페이지로 이동합니다...',
    'pricing.confirm.purchase': '{planName}을(를) 구매하시겠습니까?\n\n금액: ₩{price}/{period}\n\n※ 현재는 데모 모드입니다. 실제 결제는 진행되지 않습니다.',
    'pricing.error.payment': '결제 처리 중 오류가 발생했습니다.'
  },

  en: {
    // Header
    'header.title': 'BRIDGE Pages',
    'header.subtitle': 'Turn AI conversations into blog content',

    // Main button
    'button.startCapture': 'Start Selection',

    // Empty state
    'empty.title': 'No captured content yet',
    'empty.description': 'Click the "Start Selection" button above\nto capture AI conversation content',
    'empty.hint': 'Expand captured content in the blog editor',

    // Result area
    'result.copy': 'Copy',
    'result.goToEditor': 'Go to Editor',
    'result.capturedText': 'Captured Text',
    'result.loading': 'Opening editor...',

    // Tabs
    'tab.main': 'BRIDGE Pages',
    'tab.history': 'History',
    'tab.pricing': 'Pricing',

    // History
    'history.clearAll': 'Clear All',
    'history.empty': 'No saved captures yet',

    // Footer
    'footer.settings': 'Settings',

    // Settings modal
    'settings.title': 'Settings',
    'settings.googleLogin': 'Sign in with Google',
    'settings.googleLogout': 'Sign out from Google',
    'settings.language': 'Language',
    'settings.plan': 'Current Plan',
    'settings.remaining': 'Remaining',
    'settings.theme': 'Theme',
    'settings.themeSystem': 'Follow system settings',
    'settings.themeLight': 'Light mode',
    'settings.themeDark': 'Dark mode',
    'settings.autoRedirect': 'Auto-open Editor',
    'settings.advanced': 'Advanced Settings',
    'settings.defaultClickMode': 'Default Click Mode',
    'settings.defaultClickModeText': 'From text position (Shift=full block)',
    'settings.defaultClickModeDiv': 'Full message block (Shift=text)',
    'settings.editorUrl': 'Editor URL',
    'settings.editorUrlDesc': 'BRIDGE Pages editor address',
    'settings.info': 'Information',
    'settings.infoDesc': 'Expand AI conversations into SEO-optimized blog content',
    'settings.supportedSites': 'Supported sites:',
    'settings.copyright': 'Product by BRIDGE',
    'settings.reset': 'Reset',
    'settings.save': 'Save',
    'settings.unlimited': 'Unlimited',

    // Toast messages
    'toast.settingsSaved': 'Settings saved!',
    'toast.settingsReset': 'Settings reset to defaults!',
    'toast.copied': 'Copied to clipboard!',
    'toast.historyLoaded': 'Loaded from history',
    'toast.googleLoginSoon': 'Google login coming soon!',
    'toast.captureComplete': 'Capture completed!',
    'toast.selectionModeActivated': 'Selection mode activated!',
    'toast.noOriginalText': 'No original text to copy',
    'toast.originalCopied': 'Original text copied to clipboard!',
    'toast.noTextToEdit': 'No text to edit in the editor',
    'toast.openingEditor': 'Opening editor...',
    'toast.historyLoadFailed': 'Failed to load history',
    'toast.historyItemDeleted': 'History item deleted',
    'toast.historyDeleteFailed': 'Delete failed',
    'toast.historyAllDeleted': 'All history deleted',
    'toast.noUsageRemaining': 'No usage remaining. Please purchase a plan.',
    'toast.usageRemaining': 'Remaining usage: {count} times',
    'toast.usageExhausted': 'All available usage has been exhausted.',
    'toast.googleLoginProcessing': 'Signing in with Google...',
    'toast.googleLoginSuccess': 'Welcome, {name}!',
    'toast.googleLoginFailed': 'Google sign-in failed.',
    'toast.googleLogoutSuccess': 'Signed out from Google',

    // Confirm messages
    'confirm.resetSettings': 'Reset all settings to defaults?',
    'confirm.googleLogout': 'Sign out from {email}?',

    // Message role labels
    'role.user': 'User',
    'role.ai': 'AI',

    // Pricing/Plans
    'pricing.free': 'Free',
    'pricing.period.forever': 'Forever',
    'pricing.period.times': 'times',
    'pricing.period.month': 'month',
    'pricing.badge.popular': 'Popular',
    'pricing.feature.usage': 'Usage',
    'pricing.feature.history': 'Save {count} history items',
    'pricing.feature.historyUnlimited': 'Unlimited history (1 month retention)',
    'pricing.feature.blogExpansion': 'AI Blog Expansion',
    'pricing.feature.seoOptimization': 'SEO Optimization',
    'pricing.feature.autoPublish': 'Auto Blog Publishing',
    'pricing.button.current': 'Current Plan',
    'pricing.button.startFree': 'Start Free',
    'pricing.button.purchase': 'Purchase',
    'pricing.faq.title': 'Frequently Asked Questions',
    'pricing.faq.q1': '🎫 How do usage-based plans work?',
    'pricing.faq.a1': 'Basic 30 and Standard 70 are prepaid plans that give you a set number of uses. They remain valid until depleted. For unlimited usage, choose the MAX plan.',
    'pricing.faq.q2': '⏱️ How long can I use the MAX plan?',
    'pricing.faq.a2': 'MAX plan is a monthly subscription that automatically renews. You can cancel anytime and continue using until the next billing date.',
    'pricing.faq.q3': '💳 What payment methods are supported?',
    'pricing.faq.a3': 'We accept credit cards, debit cards, and bank transfers. All payments are securely processed through our payment gateway.',
    'pricing.faq.q4': '🔄 Can I change my plan?',
    'pricing.faq.a4': 'Yes, you can upgrade to a higher plan anytime. Your remaining usage will be preserved, and additional features become immediately available.',
    'pricing.faq.q5': '💰 What is the refund policy?',
    'pricing.faq.a5': 'Full refunds are available within 7 days of purchase if unused. After use, refunds are prorated based on remaining usage.',
    'pricing.toast.comingSoon': 'Plan purchase feature coming soon!',
    'pricing.toast.confirmPurchase': 'Are you sure you want to purchase the {planName} plan?',
    'pricing.toast.alreadyCurrent': 'This is already your current plan!',
    'pricing.toast.purchaseSuccess': '{planName} plan purchase completed!',
    'pricing.toast.switchedToFree': 'Switched to Free plan!',
    'pricing.toast.processing': 'Processing payment...',
    'pricing.toast.limitReached': 'Usage limit reached. Please recharge in the Pricing tab!',
    'pricing.toast.paidPlanNotAvailable': 'Paid plans are currently being prepared. Please enjoy free access during the beta period!',
    'pricing.toast.betaFreeOnly': '🎉 Enjoy free access during the beta period! Paid plans will be available after official launch.',
    'pricing.toast.redirecting': 'Redirecting to payment page...',
    'pricing.confirm.purchase': 'Do you want to purchase {planName}?\n\nPrice: ₩{price}/{period}\n\n※ This is demo mode. No actual payment will be processed.',
    'pricing.error.payment': 'An error occurred while processing payment.'
  }
};
