/**
 * Settings Component
 * Phase 2 - 사용자 설정 관리
 */

import { ErrorHandler } from './ErrorHandler.js';
import { i18n } from '../i18n/i18n.js';
import { GoogleAuthService } from '../services/GoogleAuthService.js';

export class Settings {
  constructor(toast = null, errorHandler = null, onThemeChange = null, apiService = null) {
    this.googleAuthService = new GoogleAuthService();
    this.settingsModal = document.getElementById('settingsModal');
    this.settingsBtn = document.getElementById('settingsBtn');
    this.closeSettingsBtn = document.getElementById('closeSettingsBtn');
    this.saveSettingsBtn = document.getElementById('saveSettingsBtn');
    this.resetSettingsBtn = document.getElementById('resetSettingsBtn');

    // Google 로그인 관련 요소
    this.googleLoginBtn = document.getElementById('googleLoginBtn');
    this.googleProfileArea = document.getElementById('googleProfileArea');
    this.profileAvatarBtn = document.getElementById('profileAvatarBtn');
    this.profileAvatar = document.getElementById('profileAvatar');
    this.profilePlanType = document.getElementById('profilePlanType');
    this.profileRemaining = document.getElementById('profileRemaining');

    // 설정 입력 요소
    this.languageSetting = document.getElementById('languageSetting');
    this.themeModeSetting = document.getElementById('themeModeSetting');
    this.useAiProcessingSetting = document.getElementById('useAiProcessingSetting');

    // 고급 설정 요소
    this.advancedSettingsToggle = document.getElementById('advancedSettingsToggle');
    this.advancedSettingsContent = document.getElementById('advancedSettingsContent');
    this.advancedSettingsBadge = document.getElementById('advancedSettingsBadge');
    this.defaultClickModeSetting = document.getElementById('defaultClickModeSetting');
    this.processApiUrl = document.getElementById('processApiUrl'); // 사용자 입력: 입력 AI 주소
    this.finalApiUrl = document.getElementById('finalApiUrl'); // 사용자 입력: 출력 AI 주소

    this.toast = toast;
    this.errorHandler = errorHandler;
    this.onThemeChange = onThemeChange; // 테마 변경 콜백
    this.apiService = apiService; // Phase 2: API Service for webhook management

    // 기본 설정값
    this.defaultSettings = {
      maxHistory: 3, // 프리 플랜: 3개, 유료 플랜: 10개
      language: 'ko', // 'ko' | 'en'
      defaultClickMode: 'text', // 'text' | 'div' - 기본 클릭 동작 ('text': 일반=텍스트/Shift=div, 'div': 일반=div/Shift=텍스트)
      themeMode: 'system', // 'system' | 'light' | 'dark' - 테마 모드
      useAiProcessing: true, // AI 정리 기능 사용 여부
      isPaidPlan: false, // 플랜 상태 (false: 프리, true: 유료)
      planType: 'free', // 'free' | 'basic30' | 'standard100' | 'max'
      remainingUsage: 0, // 잔여 사용 횟수 (월정액은 -1로 표시)
      googleUser: null, // 구글 사용자 정보
      webhookUrl: '', // Phase 2: n8n Webhook URL (환경별 설정)
      processApiUrl: '', // Standard100+ 플랜: 사용자 입력 AI 주소 (입력 처리용)
      finalApiUrl: '' // Standard100+ 플랜: 사용자 출력 AI 주소 (어조 조정용)
    };

    this.currentSettings = { ...this.defaultSettings };

    this.init();
  }

  async init() {
    // 저장된 설정 불러오기
    await this.load();

    // 이벤트 리스너 등록
    this.attachEventListeners();

    // 시스템 테마 변경 감지
    const darkModeMediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    darkModeMediaQuery.addEventListener('change', (e) => {
      if (this.currentSettings.themeMode === 'system') {
        this.applyTheme(e.matches);
      }
    });

    // 언어 변경 감지 (다른 컴포넌트에서 언어 변경 시 Settings UI도 업데이트)
    i18n.onLanguageChange((lang) => {
      this.updateAdvancedSettingsAccess(); // placeholder 업데이트
      this.updateSelectOptions(); // select 옵션 텍스트 업데이트
      this.updateGoogleLoginButton(); // Google 로그인 버튼 텍스트 업데이트
    });

    // 플랜 업데이트 이벤트 리스너 (Pricing 탭에서 플랜 구매 시)
    window.addEventListener('planUpdated', async (event) => {
      await this.load(); // 설정 다시 로드
      this.updatePlanInfo(); // 프로필 영역 플랜 정보 업데이트
    });

    // 로그인 상태 초기화 (백그라운드에서 체크)
    this.initializeGoogleAuth();
  }

  /**
   * Google OAuth 초기화 (로그인 상태 복원)
   */
  async initializeGoogleAuth() {
    try {
      const user = await this.googleAuthService.checkLoginStatus();
      if (user) {
        this.currentSettings.googleUser = user;
        this.updateGoogleLoginButton();
        console.log('Google login restored:', user.email);
      }
    } catch (error) {
      console.error('Failed to initialize Google auth:', error);
    }
  }

  /**
   * 이벤트 리스너 등록
   */
  attachEventListeners() {
    // 설정 열기
    this.settingsBtn.addEventListener('click', () => this.open());

    // 설정 닫기
    this.closeSettingsBtn.addEventListener('click', () => this.close());

    // 오버레이 클릭 시 닫기
    this.settingsModal.querySelector('.settings-modal-overlay').addEventListener('click', () => {
      this.close();
    });

    // ESC 키로 닫기
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.isOpen()) {
        this.close();
      }
    });

    // 저장 버튼
    this.saveSettingsBtn.addEventListener('click', () => this.save());

    // 재설정 버튼
    this.resetSettingsBtn.addEventListener('click', () => this.reset());

    // 구글 로그인/로그아웃 버튼
    this.googleLoginBtn.addEventListener('click', () => this.handleGoogleLogin());
    this.profileAvatarBtn.addEventListener('click', () => this.handleGoogleLogout());

    // 테마 모드 실시간 적용
    this.themeModeSetting.addEventListener('change', () => {
      const themeMode = this.themeModeSetting.value;
      if (themeMode === 'system') {
        const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        this.applyTheme(isDark);
      } else {
        this.applyTheme(themeMode === 'dark');
      }
    });

    // 언어 설정 실시간 적용
    this.languageSetting.addEventListener('change', () => {
      const language = this.languageSetting.value;
      i18n.setLanguage(language);
      // select 옵션 텍스트도 번역 적용
      this.updateSelectOptions();
    });

    // 고급 설정 토글
    this.advancedSettingsToggle.addEventListener('click', () => {
      this.toggleAdvancedSettings();
    });
  }

  /**
   * 설정 모달 열기
   */
  async open() {
    this.settingsModal.style.display = 'flex';

    // 최신 설정값 로드 후 UI에 반영
    await this.load();
    this.renderSettings();
  }

  /**
   * 설정 모달 닫기
   */
  close() {
    this.settingsModal.style.display = 'none';
  }

  /**
   * 모달이 열려있는지 확인
   */
  isOpen() {
    return this.settingsModal.style.display === 'flex';
  }

  /**
   * 현재 설정값을 UI에 렌더링
   */
  renderSettings() {
    this.languageSetting.value = this.currentSettings.language;
    this.themeModeSetting.value = this.currentSettings.themeMode;
    this.useAiProcessingSetting.checked = this.currentSettings.useAiProcessing !== false;

    // 고급 설정
    this.defaultClickModeSetting.value = this.currentSettings.defaultClickMode || 'text';

    // Phase 2: 사용자 API 주소 (Standard100+ 플랜용)
    if (this.processApiUrl) {
      this.processApiUrl.value = this.currentSettings.processApiUrl || '';
    }
    if (this.finalApiUrl) {
      this.finalApiUrl.value = this.currentSettings.finalApiUrl || '';
    }

    // 구글 로그인 버튼 상태 업데이트
    this.updateGoogleLoginButton();

    // 플랜에 따른 히스토리 설정 업데이트
    this.updateHistorySettings();

    // 잔여 사용 횟수 업데이트
    this.updateRemainingUsage();

    // 고급 설정 뱃지 및 버튼 상태 업데이트
    this.updateAdvancedSettingsAccess();
  }

  /**
   * 플랜에 따른 히스토리 설정 업데이트
   */
  updateHistorySettings() {
    const planType = this.currentSettings.planType || 'free';
    const isPaid = planType !== 'free';
    const maxHistory = isPaid ? 10 : 3;

    // 플랜이 변경되면 maxHistory 자동 업데이트
    if (this.currentSettings.maxHistory !== maxHistory) {
      this.currentSettings.maxHistory = maxHistory;
    }

    // isPaidPlan 상태도 동기화
    this.currentSettings.isPaidPlan = isPaid;

    // 프로필 영역 플랜 정보 업데이트 (로그인 상태일 때만)
    if (this.currentSettings.googleUser) {
      this.updatePlanInfo();
    }
  }

  /**
   * 잔여 사용 횟수 업데이트
   */
  updateRemainingUsage() {
    // 프로필 영역 플랜 정보 업데이트 (로그인 상태일 때만)
    if (this.currentSettings.googleUser) {
      this.updatePlanInfo();
    }
  }

  /**
   * UI에서 설정값 읽기
   * 중요: googleUser, planType, remainingUsage는 최상위에서 관리되므로 여기서 저장하지 않음
   */
  readSettingsFromUI() {
    // maxHistory는 플랜에 따라 자동 설정
    const planType = this.currentSettings.planType || 'free';
    const maxHistory = planType !== 'free' ? 10 : 3;

    return {
      maxHistory: maxHistory,
      language: this.languageSetting.value,
      defaultClickMode: this.defaultClickModeSetting.value,
      themeMode: this.themeModeSetting.value,
      useAiProcessing: this.useAiProcessingSetting.checked,
      isPaidPlan: this.currentSettings.isPaidPlan,
      // planType, remainingUsage, googleUser는 최상위 키에서 관리 (여기서 저장하지 않음)
      webhookUrl: this.currentSettings.webhookUrl, // 하드코딩된 n8n Webhook URL
      processApiUrl: this.processApiUrl?.value.trim() || '', // 사용자 입력 AI 주소
      finalApiUrl: this.finalApiUrl?.value.trim() || '' // 사용자 출력 AI 주소
    };
  }

  /**
   * 설정 저장
   */
  async save() {
    try {
      // UI에서 설정값 읽기
      const newSettings = this.readSettingsFromUI();

      // Chrome Storage에 저장
      const saved = await ErrorHandler.safeStorageSet({ settings: newSettings });

      if (!saved) {
        if (this.errorHandler) {
          this.errorHandler.handle(
            new Error('Failed to save settings'),
            'saveSettings',
            { customMessage: '설정 저장에 실패했습니다.' }
          );
        }
        return;
      }

      // 현재 설정 업데이트 (최상위 키 값 보존!)
      const preservedGoogleUser = this.currentSettings.googleUser;
      const preservedPlanType = this.currentSettings.planType;
      const preservedRemainingUsage = this.currentSettings.remainingUsage;

      this.currentSettings = {
        ...newSettings,
        googleUser: preservedGoogleUser,
        planType: preservedPlanType,
        remainingUsage: preservedRemainingUsage
      };

      // 테마 적용
      if (newSettings.themeMode === 'system') {
        const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        this.applyTheme(isDark);
      } else {
        this.applyTheme(newSettings.themeMode === 'dark');
      }

      // 성공 메시지
      if (this.toast) {
        this.toast.success(i18n.t('toast.settingsSaved'));
      }

      // 모달 닫기
      this.close();

      console.log('Settings saved:', this.currentSettings);
    } catch (error) {
      if (this.errorHandler) {
        this.errorHandler.handle(error, 'saveSettings');
      } else {
        console.error('Failed to save settings:', error);
      }
    }
  }

  /**
   * 설정 불러오기
   */
  async load() {
    try {
      // settings 객체와 최상위 정보 모두 가져오기 (googleUser 포함!)
      const result = await ErrorHandler.safeStorageGet([
        'settings', 'planType', 'remainingUsage', 'planPurchaseDate', 'googleUser'
      ]);

      if (result.settings) {
        this.currentSettings = {
          ...this.defaultSettings,
          ...result.settings
        };
      } else {
        this.currentSettings = { ...this.defaultSettings };
      }

      // 최상위 플랜 정보로 항상 덮어쓰기 (settings 내부보다 우선)
      // undefined인 경우 기본값 'free'로 설정 (데이터 불일치 방지)
      this.currentSettings.planType = result.planType ?? 'free';
      this.currentSettings.remainingUsage = result.remainingUsage ?? 0;
      if (result.planPurchaseDate !== undefined) {
        this.currentSettings.planPurchaseDate = result.planPurchaseDate;
      }

      // googleUser도 최상위에서 로드 (GoogleAuthService에서 저장한 것 우선)
      if (result.googleUser) {
        this.currentSettings.googleUser = result.googleUser;
      }

      // 테마 적용
      if (this.currentSettings.themeMode === 'system') {
        const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        this.applyTheme(isDark);
      } else {
        this.applyTheme(this.currentSettings.themeMode === 'dark');
      }

      console.log('Settings loaded:', this.currentSettings);
    } catch (error) {
      if (this.errorHandler) {
        this.errorHandler.handle(error, 'loadSettings', { silent: true });
      } else {
        console.error('Failed to load settings:', error);
      }

      // 에러 시 기본값 사용
      this.currentSettings = { ...this.defaultSettings };
    }
  }

  /**
   * 기본값으로 재설정
   * 중요: 로그인 상태(googleUser), 플랜 정보는 유지
   */
  async reset() {
    try {
      // 확인 메시지
      const confirmed = confirm(i18n.t('confirm.resetSettings'));
      if (!confirmed) return;

      // 보존해야 할 값들 백업
      const preservedGoogleUser = this.currentSettings.googleUser;
      const preservedPlanType = this.currentSettings.planType;
      const preservedRemainingUsage = this.currentSettings.remainingUsage;

      // 기본값으로 설정 (보존 값 유지)
      this.currentSettings = {
        ...this.defaultSettings,
        googleUser: preservedGoogleUser,
        planType: preservedPlanType,
        remainingUsage: preservedRemainingUsage
      };

      // Chrome Storage에 저장 (settings 객체만 - 최상위 키는 건드리지 않음)
      const settingsToSave = { ...this.defaultSettings };
      delete settingsToSave.googleUser;
      delete settingsToSave.planType;
      delete settingsToSave.remainingUsage;

      const saved = await ErrorHandler.safeStorageSet({ settings: settingsToSave });

      if (!saved) {
        if (this.errorHandler) {
          this.errorHandler.handle(
            new Error('Failed to reset settings'),
            'resetSettings',
            { customMessage: '설정 재설정에 실패했습니다.' }
          );
        }
        return;
      }

      // UI 업데이트
      this.renderSettings();

      // 테마 적용
      if (this.currentSettings.themeMode === 'system') {
        const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        this.applyTheme(isDark);
      } else {
        this.applyTheme(this.currentSettings.themeMode === 'dark');
      }

      // 성공 메시지
      if (this.toast) {
        this.toast.success(i18n.t('toast.settingsReset'));
      }

      // 언어도 기본값(ko)으로 재설정
      i18n.setLanguage('ko');
      this.updateSelectOptions();

      console.log('Settings reset to default (auth preserved)');
    } catch (error) {
      if (this.errorHandler) {
        this.errorHandler.handle(error, 'resetSettings');
      } else {
        console.error('Failed to reset settings:', error);
      }
    }
  }

  /**
   * 테마 적용
   */
  applyTheme(isDarkMode) {
    if (isDarkMode) {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }

    // 테마 변경 콜백 호출
    if (this.onThemeChange) {
      this.onThemeChange(isDarkMode);
    }
  }

  /**
   * 현재 설정 가져오기
   */
  getSettings() {
    return { ...this.currentSettings };
  }

  /**
   * 특정 설정값 가져오기
   */
  getSetting(key) {
    return this.currentSettings[key];
  }

  /**
   * 특정 설정값 업데이트 (프로그래매틱)
   */
  async updateSetting(key, value) {
    try {
      this.currentSettings[key] = value;

      // 플랜 타입 변경 시 처리
      if (key === 'planType') {
        this.updateHistorySettings();
        this.updateRemainingUsage();
        this.updateAdvancedSettingsAccess();
      }

      // 잔여 사용 횟수 변경 시 처리
      if (key === 'remainingUsage') {
        this.updateRemainingUsage();
      }

      // 레거시 isPaidPlan 변경 시 처리 (하위 호환성)
      if (key === 'isPaidPlan') {
        const newMaxHistory = value ? 10 : 3;
        this.currentSettings.maxHistory = newMaxHistory;
        this.updateHistorySettings();
        this.updateAdvancedSettingsAccess();
      }

      const saved = await ErrorHandler.safeStorageSet({ settings: this.currentSettings });

      if (!saved) {
        throw new Error('Failed to save setting');
      }

      // remainingUsage는 최상위 키로도 저장 (sidepanel storage listener용)
      if (key === 'remainingUsage') {
        await ErrorHandler.safeStorageSet({ remainingUsage: value });
        console.log(`Top-level remainingUsage also updated: ${value}`);
      }

      // 테마 설정이 변경된 경우
      if (key === 'themeMode') {
        if (value === 'system') {
          const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
          this.applyTheme(isDark);
        } else {
          this.applyTheme(value === 'dark');
        }
      }

      console.log(`Setting updated: ${key} = ${value}`);
      return true;
    } catch (error) {
      if (this.errorHandler) {
        this.errorHandler.handle(error, 'updateSetting', { silent: true });
      }
      return false;
    }
  }

  /**
   * 구글 로그인 버튼/프로필 카드 상태 업데이트
   */
  updateGoogleLoginButton() {
    if (!this.googleLoginBtn || !this.googleProfileArea) return;

    if (this.currentSettings.googleUser) {
      // 로그인된 상태 - 프로필 영역 표시
      this.googleLoginBtn.style.display = 'none';
      this.googleProfileArea.style.display = 'block';

      // 프로필 이미지 설정 (Google 제공 이미지 또는 기본 아바타)
      const user = this.currentSettings.googleUser;
      if (user.picture) {
        this.profileAvatar.src = user.picture;
      } else {
        // 기본 아바타 (첫 글자로 생성)
        const initial = (user.name || user.email).charAt(0).toUpperCase();
        this.profileAvatar.alt = initial;
        // SVG 데이터 URI로 기본 아바타 생성 (Google 스타일 색상)
        const svg = `data:image/svg+xml,${encodeURIComponent(`
          <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40">
            <rect width="40" height="40" fill="%234285f4"/>
            <text x="50%" y="50%" font-size="18" font-weight="500" fill="white" text-anchor="middle" dominant-baseline="central" font-family="system-ui, -apple-system, sans-serif">
              ${initial}
            </text>
          </svg>
        `)}`;
        this.profileAvatar.src = svg;
      }

      // 플랜 타입과 잔여량 업데이트
      this.updatePlanInfo();
    } else {
      // 로그아웃 상태 - 로그인 버튼 표시
      this.googleLoginBtn.style.display = 'flex';
      this.googleProfileArea.style.display = 'none';
    }
  }

  /**
   * 플랜 정보 업데이트 (프로필 영역)
   */
  updatePlanInfo() {
    const planType = this.currentSettings.planType || 'free';
    const remaining = this.currentSettings.remainingUsage;

    // 플랜 타입 표시 (Pricing.js와 일치)
    const planNames = {
      'free': 'Free',
      'basic30': 'Basic 30',
      'standard70': 'Standard 70',
      'max': 'MAX'
    };
    this.profilePlanType.textContent = planNames[planType] || 'Free';

    // 잔여량 표시
    if (planType === 'max') {
      this.profileRemaining.textContent = '∞';
    } else {
      this.profileRemaining.textContent = remaining !== undefined ? remaining : 0;
    }
  }

  /**
   * 고급 설정 접근 권한 업데이트
   */
  updateAdvancedSettingsAccess() {
    const isPaid = this.currentSettings.isPaidPlan;

    if (isPaid) {
      // Standard100 이상 플랜: 입력 가능
      this.processApiUrl.disabled = false;
      this.finalApiUrl.disabled = false;
      this.processApiUrl.placeholder = i18n.t('settings.apiKeyPlaceholder');
      this.finalApiUrl.placeholder = i18n.t('settings.apiKeyPlaceholder');
      this.advancedSettingsBadge.textContent = i18n.t('settings.apiKeyBadge');
      this.advancedSettingsBadge.classList.remove('free');
    } else {
      // Free, Basic30 플랜: 입력 불가 (보기만 가능)
      this.processApiUrl.disabled = true;
      this.finalApiUrl.disabled = true;
      this.processApiUrl.placeholder = i18n.t('settings.apiKeyDisabled');
      this.finalApiUrl.placeholder = i18n.t('settings.apiKeyDisabled');
      this.advancedSettingsBadge.textContent = i18n.t('settings.apiKeyBadge');
      this.advancedSettingsBadge.classList.add('free');
    }
  }

  /**
   * 고급 설정 토글
   */
  toggleAdvancedSettings() {
    const isOpen = this.advancedSettingsContent.style.display === 'block';

    if (isOpen) {
      // 닫기
      this.advancedSettingsContent.style.display = 'none';
      this.advancedSettingsToggle.classList.remove('open');
    } else {
      // 열기
      this.advancedSettingsContent.style.display = 'block';
      this.advancedSettingsToggle.classList.add('open');

      // Free, Basic30 플랜이면 안내 메시지 표시
      if (!this.currentSettings.isPaidPlan && this.toast) {
        this.toast.info(i18n.t('toast.advancedPlanRequired'), 3000);
      }
    }
  }

  /**
   * Select 옵션 텍스트 업데이트 (언어 변경 시)
   */
  updateSelectOptions() {
    // 테마 모드 옵션
    const themeOptions = this.themeModeSetting.querySelectorAll('option');
    themeOptions.forEach(option => {
      const key = option.getAttribute('data-i18n');
      if (key) {
        option.textContent = i18n.t(key);
      }
    });

    // 기본 클릭 모드 옵션
    const defaultClickOptions = this.defaultClickModeSetting.querySelectorAll('option');
    defaultClickOptions.forEach(option => {
      const key = option.getAttribute('data-i18n');
      if (key) {
        option.textContent = i18n.t(key);
      }
    });
  }

  /**
   * 구글 로그인 처리
   */
  async handleGoogleLogin() {
    console.log('=== handleGoogleLogin called ===');
    try {
      // 로그인 시도
      console.log('Showing login processing toast...');
      if (this.toast) {
        this.toast.info(i18n.t('toast.googleLoginProcessing'));
      }

      console.log('Calling googleAuthService.login()...');
      const user = await this.googleAuthService.login();
      console.log('Login result:', user);
      this.currentSettings.googleUser = user;
      this.updateGoogleLoginButton();

      // 로그인 성공 이벤트 발생 (히스토리 동기화 등에 사용)
      window.dispatchEvent(new CustomEvent('loginSuccess', {
        detail: { user }
      }));

      if (this.toast) {
        this.toast.success(
          i18n.t('toast.googleLoginSuccess')
            .replace('{name}', user.name || user.email)
        );
      }
    } catch (error) {
      console.error('Google login error:', error);

      if (this.toast) {
        this.toast.error(i18n.t('toast.googleLoginFailed'));
      }

      if (this.errorHandler) {
        this.errorHandler.handle(error, 'handleGoogleLogin');
      }
    }
  }

  /**
   * 구글 로그아웃 처리
   */
  async handleGoogleLogout() {
    try {
      const currentUser = this.currentSettings.googleUser;
      if (!currentUser) return;

      // 로그아웃 확인
      const confirmed = confirm(
        i18n.t('confirm.googleLogout')
          .replace('{email}', currentUser.email)
      );

      if (!confirmed) return;

      // GoogleAuthService로 로그아웃 (Storage 제거 + 토큰 revoke)
      await this.googleAuthService.logout();

      // currentSettings 업데이트
      this.currentSettings.googleUser = null;

      // UI 업데이트
      this.updateGoogleLoginButton();

      if (this.toast) {
        this.toast.success(i18n.t('toast.googleLogoutSuccess'));
      }
    } catch (error) {
      console.error('Google logout error:', error);

      if (this.toast) {
        this.toast.error(i18n.t('toast.googleLoginFailed'));
      }

      if (this.errorHandler) {
        this.errorHandler.handle(error, 'handleGoogleLogout');
      }
    }
  }

  /**
   * 사용 횟수 차감 (파이널텍스트 생성 시 호출)
   * 중요: 백엔드에서만 사용량 관리 - 로컬 fallback 없음
   */
  async decrementUsage() {
    const planType = this.currentSettings.planType || 'free';

    // 월정액(MAX)만 차감하지 않음
    if (planType === 'max') {
      return true;
    }

    // 베타 기간: 로그인 안 된 상태에서는 사용량 무제한 (테스트용)
    const backendService = this.googleAuthService.getBackendService();
    if (!backendService.isAuthenticated()) {
      console.log('Beta mode: No backend auth, allowing usage without tracking');
      return true;
    }

    // 백엔드에서 사용량 차감 (로컬 fallback 없음)
    try {
      console.log('Calling backend incrementUsage...');
      const result = await backendService.incrementUsage('notes');
      console.log('Backend incrementUsage result:', result);

      // 백엔드에서 받은 잔여량으로 로컬 업데이트 (표시용 캐시만)
      const newRemaining = result.remaining;
      await this.updateSettingDisplayCache('remainingUsage', newRemaining);

      // 횟수가 떨어지면 알림
      if (newRemaining <= 5 && newRemaining > 0) {
        if (this.toast) {
          this.toast.info(i18n.t('toast.usageRemaining').replace('{count}', newRemaining), 3000);
        }
      } else if (newRemaining === 0) {
        if (this.toast) {
          this.toast.error(i18n.t('toast.usageExhausted'));
        }
      }

      return true;

    } catch (error) {
      console.error('Backend usage decrement failed:', error);

      // 사용량 초과 에러 - 차단
      if (error.message.includes('limit exceeded')) {
        if (this.toast) {
          this.toast.error(i18n.t('toast.noUsageRemaining'));
        }
        return false;
      }

      // 기타 에러 - 베타 기간에는 허용 (백엔드 복구 후 동기화)
      console.warn('Backend error, allowing usage in beta mode');
      return true;
    }
  }

  /**
   * 표시용 캐시 업데이트 (실제 제한은 백엔드에서 관리)
   * 로컬 Storage는 UI 표시용 캐시일 뿐
   */
  async updateSettingDisplayCache(key, value) {
    this.currentSettings[key] = value;

    // Storage에도 저장하지만 이건 표시용 캐시일 뿐
    await ErrorHandler.safeStorageSet({ [key]: value });
    console.log(`Display cache updated: ${key} = ${value}`);
  }

  /**
   * 사용 가능 여부 확인
   * 베타 기간: 로그인 안 된 상태에서도 허용
   */
  canUseService() {
    const planType = this.currentSettings.planType || 'free';
    const remaining = this.currentSettings.remainingUsage;

    // 월정액(MAX)은 항상 사용 가능
    if (planType === 'max') {
      return true;
    }

    // 베타 기간: 로그인 안 된 상태에서는 사용 가능 (테스트용)
    const backendService = this.googleAuthService.getBackendService();
    if (!backendService.isAuthenticated()) {
      console.log('Beta mode: No backend auth, allowing service use');
      return true;
    }

    // 로그인된 사용자는 잔여 횟수 확인 (표시용 캐시 기반, 실제 제한은 백엔드)
    return remaining !== undefined && remaining > 0;
  }

  /**
   * 백엔드에서 실시간 사용량 확인
   * @returns {Promise<{allowed: boolean, remaining: number}>}
   */
  async checkUsageFromBackend() {
    try {
      const backendService = this.googleAuthService.getBackendService();
      if (!backendService.isAuthenticated()) {
        // 베타 기간: 로그인 안 된 상태에서는 허용
        return { allowed: true, remaining: 999 };
      }

      const result = await backendService.checkUsage('notes');
      console.log('Backend usage check:', result);

      // 표시용 캐시 업데이트
      await this.updateSettingDisplayCache('remainingUsage', result.remaining);

      return result;
    } catch (error) {
      console.error('Backend usage check failed:', error);
      // 에러 시에도 베타 기간에는 허용
      return { allowed: true, remaining: this.currentSettings.remainingUsage || 0 };
    }
  }

  /**
   * BackendService 인스턴스 가져오기
   * HistoryService와 연동에 사용
   * @returns {BackendService}
   */
  getBackendService() {
    return this.googleAuthService.getBackendService();
  }

  /**
   * 로그인 상태 확인
   * @returns {boolean}
   */
  isAuthenticated() {
    return this.googleAuthService.getBackendService().isAuthenticated();
  }
}
