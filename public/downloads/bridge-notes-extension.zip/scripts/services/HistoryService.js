/**
 * HistoryService - Chrome Storage 기반 노트 히스토리 관리
 * 로그인 시 백엔드와 동기화
 */
export class HistoryService {
  constructor() {
    this.maxHistorySize = 10; // 기본값 (유료)
    this.storageKey = 'bridgeNotesHistory';
    this.initialized = false;
    this.backendService = null; // 외부에서 주입
  }

  /**
   * BackendService 인스턴스 설정
   * @param {BackendService} backendService
   */
  setBackendService(backendService) {
    this.backendService = backendService;
  }

  /**
   * 플랜에 따라 히스토리 제한 설정
   * @param {string} planType - free, basic30, standard70, max
   */
  async initializeWithPlan(planType) {
    if (planType === 'free') {
      this.maxHistorySize = 3;
    } else if (planType === 'max') {
      this.maxHistorySize = -1; // 무제한
    } else {
      // basic30, standard70 모두 10개
      this.maxHistorySize = 10;
    }
    this.initialized = true;
    console.log(`HistoryService initialized: planType=${planType}, maxHistorySize=${this.maxHistorySize}`);
  }

  /**
   * 히스토리 항목 추가
   * @param {Object} item - 저장할 노트 항목
   * @param {string} item.originalText - 원본 텍스트
   * @param {string} item.processedText - 처리된 텍스트
   * @param {string} item.template - 사용한 템플릿
   * @param {string} item.tone - 사용한 어조
   * @param {Object} item.metadata - 추가 메타데이터
   */
  async addToHistory(item) {
    try {
      // planType 확인 및 초기화
      if (!this.initialized) {
        const result = await chrome.storage.local.get(['planType']);
        const planType = result.planType || 'free';
        await this.initializeWithPlan(planType);
      }

      // 로컬 스토리지에 저장
      const localItem = await this.addToLocalHistory(item);

      // 백엔드 동기화 (로그인 상태 시)
      if (this.backendService?.isAuthenticated()) {
        try {
          await this.backendService.saveHistory({
            originalText: item.originalText,
            processedText: item.processedText,
            tone: item.tone,
            sourceUrl: item.sourceUrl,
            metadata: item.metadata,
          });
          console.log('History synced to backend');
        } catch (error) {
          // 백엔드 실패해도 로컬은 저장됨
          console.warn('Backend history sync failed:', error);
        }
      }

      return localItem;
    } catch (error) {
      console.error('History add error:', error);
      throw error;
    }
  }

  /**
   * 로컬 스토리지에 히스토리 추가 (내부용)
   */
  async addToLocalHistory(item) {
    const history = await this.getLocalHistory();

    const newItem = {
      id: Date.now().toString(),
      timestamp: Date.now(),
      originalText: item.originalText,
      processedText: item.processedText,
      template: item.template || 'knowledge',
      tone: item.tone || 'friendly',
      preview: this.generatePreview(item.processedText),
      metadata: item.metadata || {}
    };

    // 최신 항목을 앞에 추가
    history.unshift(newItem);

    // 최대 개수 제한 (무제한이 아닌 경우)
    if (this.maxHistorySize !== -1 && history.length > this.maxHistorySize) {
      history.splice(this.maxHistorySize);
    }

    await chrome.storage.local.set({ [this.storageKey]: history });
    return newItem;
  }

  /**
   * 로컬 히스토리만 조회 (내부용)
   */
  async getLocalHistory() {
    try {
      const result = await chrome.storage.local.get([this.storageKey]);
      return result[this.storageKey] || [];
    } catch (error) {
      console.error('Local history get error:', error);
      return [];
    }
  }

  /**
   * 전체 히스토리 조회
   * 로그인 시 백엔드 데이터 우선, 비로그인 시 로컬 데이터
   * @returns {Promise<Array>}
   */
  async getHistory() {
    try {
      // 로그인 상태면 백엔드에서 가져오기
      if (this.backendService?.isAuthenticated()) {
        try {
          const backendData = await this.backendService.getHistory();

          // 백엔드 형식을 로컬 형식으로 변환
          const history = backendData.history.map(item => ({
            id: item.id,
            timestamp: new Date(item.createdAt).getTime(),
            originalText: item.originalText,
            processedText: item.transformedText,
            tone: item.tone,
            preview: this.generatePreview(item.transformedText),
            metadata: item.metadata || {},
            isFromBackend: true, // 백엔드에서 온 항목 표시
          }));

          console.log(`Got ${history.length} items from backend`);
          return history;
        } catch (error) {
          console.warn('Backend history fetch failed, falling back to local:', error);
          // 백엔드 실패 시 로컬로 폴백
          return await this.getLocalHistory();
        }
      }

      // 비로그인 상태면 로컬에서 가져오기
      return await this.getLocalHistory();
    } catch (error) {
      console.error('History get error:', error);
      return [];
    }
  }

  /**
   * 특정 히스토리 항목 조회
   * @param {string} id - 항목 ID
   * @returns {Promise<Object|null>}
   */
  async getItem(id) {
    try {
      const history = await this.getHistory();
      return history.find(item => item.id === id) || null;
    } catch (error) {
      console.error('History getItem error:', error);
      return null;
    }
  }

  /**
   * 히스토리 항목 삭제
   * @param {string} id - 삭제할 항목 ID
   */
  async deleteItem(id) {
    try {
      // 로컬에서 삭제
      const history = await this.getLocalHistory();
      const filtered = history.filter(item => item.id !== id);
      await chrome.storage.local.set({ [this.storageKey]: filtered });

      // 백엔드에서도 삭제 (로그인 상태 시)
      if (this.backendService?.isAuthenticated()) {
        try {
          await this.backendService.deleteHistoryItem(id);
          console.log('History item deleted from backend');
        } catch (error) {
          console.warn('Backend history delete failed:', error);
        }
      }
    } catch (error) {
      console.error('History delete error:', error);
      throw error;
    }
  }

  /**
   * 전체 히스토리 삭제
   */
  async clearHistory() {
    try {
      // 로컬 삭제
      await chrome.storage.local.remove([this.storageKey]);

      // 백엔드에서도 삭제 (로그인 상태 시)
      if (this.backendService?.isAuthenticated()) {
        try {
          await this.backendService.clearHistory();
          console.log('History cleared from backend');
        } catch (error) {
          console.warn('Backend history clear failed:', error);
        }
      }
    } catch (error) {
      console.error('History clear error:', error);
      throw error;
    }
  }

  /**
   * 로컬 히스토리를 백엔드로 동기화
   * 로그인 직후 호출하여 기존 로컬 데이터를 백엔드에 업로드
   */
  async syncLocalToBackend() {
    if (!this.backendService?.isAuthenticated()) {
      console.log('Not authenticated, skipping sync');
      return;
    }

    try {
      const localHistory = await this.getLocalHistory();

      if (localHistory.length === 0) {
        console.log('No local history to sync');
        return;
      }

      console.log(`Syncing ${localHistory.length} local items to backend...`);

      // 오래된 순서로 동기화 (백엔드에서 LRU로 관리)
      const reversedHistory = [...localHistory].reverse();

      let syncedCount = 0;
      for (const item of reversedHistory) {
        try {
          await this.backendService.saveHistory({
            originalText: item.originalText,
            processedText: item.processedText,
            tone: item.tone,
            metadata: item.metadata,
          });
          syncedCount++;
        } catch (error) {
          console.warn('Failed to sync item:', error);
        }
      }

      console.log(`Synced ${syncedCount}/${localHistory.length} items to backend`);

      // 동기화 완료 후 로컬 히스토리 클리어 (선택적)
      // 백엔드가 primary가 되므로 로컬은 클리어할 수 있음
      // await chrome.storage.local.remove([this.storageKey]);

    } catch (error) {
      console.error('Sync to backend failed:', error);
    }
  }

  /**
   * 히스토리 통계 조회
   * @returns {Promise<Object>}
   */
  async getStats() {
    try {
      const history = await this.getHistory();
      return {
        count: history.length,
        maxSize: this.maxHistorySize,
        oldestTimestamp: history.length > 0 ? history[history.length - 1].timestamp : null,
        newestTimestamp: history.length > 0 ? history[0].timestamp : null,
        isUnlimited: this.maxHistorySize === -1,
      };
    } catch (error) {
      console.error('History stats error:', error);
      return { count: 0, maxSize: this.maxHistorySize };
    }
  }

  /**
   * 미리보기 텍스트 생성
   * @param {string} text - 전체 텍스트
   * @returns {string} - 미리보기 (최대 100자)
   */
  generatePreview(text) {
    if (!text) return '';
    const cleaned = text.trim().replace(/\n+/g, ' ');
    return cleaned.length > 100 ? cleaned.substring(0, 100) + '...' : cleaned;
  }

  /**
   * 날짜 포맷팅 (상대 시간)
   * @param {number} timestamp
   * @returns {string}
   */
  formatRelativeTime(timestamp) {
    const now = Date.now();
    const diff = now - timestamp;

    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return '방금 전';
    if (minutes < 60) return `${minutes}분 전`;
    if (hours < 24) return `${hours}시간 전`;
    if (days < 7) return `${days}일 전`;

    // 7일 이상은 날짜 표시
    const date = new Date(timestamp);
    return `${date.getMonth() + 1}/${date.getDate()}`;
  }

  /**
   * 검색
   * @param {string} query - 검색어
   * @returns {Promise<Array>}
   */
  async search(query) {
    try {
      const history = await this.getHistory();
      if (!query || query.trim() === '') return history;

      const lowerQuery = query.toLowerCase();
      return history.filter(item =>
        item.processedText.toLowerCase().includes(lowerQuery) ||
        item.originalText.toLowerCase().includes(lowerQuery) ||
        item.preview.toLowerCase().includes(lowerQuery)
      );
    } catch (error) {
      console.error('History search error:', error);
      return [];
    }
  }
}
