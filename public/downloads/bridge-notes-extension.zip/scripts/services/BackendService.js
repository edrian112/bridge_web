/**
 * BackendService - BRIDGE 백엔드 API 통신
 * 사용자 인증, 플랜 조회, 사용량 관리
 */

import { ErrorHandler } from '../components/ErrorHandler.js';

const BACKEND_URL = 'http://140.245.112.1:3000';

export class BackendService {
  constructor() {
    this.jwtToken = null;
    this.user = null;
  }

  /**
   * 초기화 - 저장된 JWT 토큰 로드
   */
  async init() {
    try {
      const result = await ErrorHandler.safeStorageGet(['backendToken', 'backendUser']);
      this.jwtToken = result.backendToken || null;
      this.user = result.backendUser || null;
      console.log('BackendService initialized:', this.jwtToken ? 'Token loaded' : 'No token');
    } catch (error) {
      console.error('BackendService init failed:', error);
    }
  }

  /**
   * 상태 초기화 - 메모리 및 스토리지 모두 클리어
   */
  async clear() {
    this.jwtToken = null;
    this.user = null;
    await ErrorHandler.safeStorageRemove(['backendToken', 'backendUser']);
    console.log('BackendService cleared');
  }

  /**
   * Google Access Token으로 백엔드 인증
   * @param {string} googleAccessToken - Chrome Identity API에서 받은 access token
   * @returns {Promise<Object>} { user, token }
   */
  async authenticateWithGoogle(googleAccessToken) {
    try {
      const response = await fetch(`${BACKEND_URL}/api/auth/google`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ accessToken: googleAccessToken }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Authentication failed');
      }

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Authentication failed');
      }

      // JWT 토큰과 사용자 정보 저장
      this.jwtToken = data.data.token;
      this.user = data.data.user;

      await ErrorHandler.safeStorageSet({
        backendToken: this.jwtToken,
        backendUser: this.user,
      });

      console.log('Backend authentication successful:', this.user.email);
      return { user: this.user, token: this.jwtToken };

    } catch (error) {
      console.error('Backend authentication failed:', error);
      throw error;
    }
  }

  /**
   * 현재 플랜 및 사용량 조회
   * @param {string} productType - 'notes' | 'pages' | 'web'
   * @returns {Promise<Object>} { user, subscription }
   */
  async getPlan(productType = 'notes') {
    if (!this.jwtToken) {
      throw new Error('Not authenticated');
    }

    try {
      const response = await fetch(`${BACKEND_URL}/api/user/plan?product=${productType}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.jwtToken}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.status === 401) {
        // 토큰 만료 - 로그아웃 처리
        await this.logout();
        throw new Error('Session expired. Please login again.');
      }

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to get plan');
      }

      const data = await response.json();
      return data.data;

    } catch (error) {
      console.error('Get plan failed:', error);
      throw error;
    }
  }

  /**
   * 사용량 확인 (사용 가능 여부)
   * @param {string} productType - 'notes' | 'pages' | 'web'
   * @returns {Promise<Object>} { allowed, remaining }
   */
  async checkUsage(productType = 'notes') {
    if (!this.jwtToken) {
      throw new Error('Not authenticated');
    }

    try {
      const response = await fetch(`${BACKEND_URL}/api/user/usage/check?product=${productType}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.jwtToken}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.status === 401) {
        await this.logout();
        throw new Error('Session expired. Please login again.');
      }

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to check usage');
      }

      const data = await response.json();
      return data.data;

    } catch (error) {
      console.error('Check usage failed:', error);
      throw error;
    }
  }

  /**
   * 사용량 차감
   * @param {string} productType - 'notes' | 'pages' | 'web'
   * @returns {Promise<Object>} { remaining }
   */
  async incrementUsage(productType = 'notes') {
    if (!this.jwtToken) {
      throw new Error('Not authenticated');
    }

    try {
      const response = await fetch(`${BACKEND_URL}/api/user/usage/increment`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.jwtToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ productType }),
      });

      if (response.status === 401) {
        await this.logout();
        throw new Error('Session expired. Please login again.');
      }

      if (response.status === 429) {
        throw new Error('Monthly usage limit exceeded');
      }

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to increment usage');
      }

      const data = await response.json();
      return data.data;

    } catch (error) {
      console.error('Increment usage failed:', error);
      throw error;
    }
  }

  /**
   * 플랜 업데이트 (구매/변경)
   * @param {string} planId - 'free' | 'basic30' | 'standard70' | 'max'
   * @param {string} productType - 'notes' | 'pages' | 'web'
   * @returns {Promise<Object>} { subscription }
   */
  async updatePlan(planId, productType = 'notes') {
    if (!this.jwtToken) {
      throw new Error('Not authenticated');
    }

    try {
      const response = await fetch(`${BACKEND_URL}/api/user/plan`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.jwtToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ planId, productType }),
      });

      if (response.status === 401) {
        await this.logout();
        throw new Error('Session expired. Please login again.');
      }

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to update plan');
      }

      const data = await response.json();
      return data.data;

    } catch (error) {
      console.error('Update plan failed:', error);
      throw error;
    }
  }

  /**
   * 로그아웃
   */
  async logout() {
    this.jwtToken = null;
    this.user = null;
    await ErrorHandler.safeStorageRemove(['backendToken', 'backendUser']);
    console.log('Backend logout successful');
  }

  // ==================== History API ====================

  /**
   * 히스토리 저장
   * @param {Object} item - 저장할 히스토리 항목
   * @returns {Promise<Object>} { history }
   */
  async saveHistory(item) {
    if (!this.jwtToken) {
      throw new Error('Not authenticated');
    }

    try {
      const response = await fetch(`${BACKEND_URL}/api/notes/history`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.jwtToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          originalText: item.originalText,
          transformedText: item.processedText || item.transformedText,
          tone: item.tone,
          sourceUrl: item.sourceUrl || window.location?.href,
          metadata: item.metadata || {},
        }),
      });

      if (response.status === 401) {
        await this.logout();
        throw new Error('Session expired. Please login again.');
      }

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to save history');
      }

      const data = await response.json();
      return data.data;

    } catch (error) {
      console.error('Save history failed:', error);
      throw error;
    }
  }

  /**
   * 히스토리 조회
   * @returns {Promise<Object>} { history: [], meta: {} }
   */
  async getHistory() {
    if (!this.jwtToken) {
      throw new Error('Not authenticated');
    }

    try {
      const response = await fetch(`${BACKEND_URL}/api/notes/history`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.jwtToken}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.status === 401) {
        await this.logout();
        throw new Error('Session expired. Please login again.');
      }

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to get history');
      }

      const data = await response.json();
      return data.data;

    } catch (error) {
      console.error('Get history failed:', error);
      throw error;
    }
  }

  /**
   * 히스토리 항목 삭제
   * @param {string} id - 삭제할 항목 ID
   * @returns {Promise<boolean>}
   */
  async deleteHistoryItem(id) {
    if (!this.jwtToken) {
      throw new Error('Not authenticated');
    }

    try {
      const response = await fetch(`${BACKEND_URL}/api/notes/history/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${this.jwtToken}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.status === 401) {
        await this.logout();
        throw new Error('Session expired. Please login again.');
      }

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to delete history');
      }

      return true;

    } catch (error) {
      console.error('Delete history failed:', error);
      throw error;
    }
  }

  /**
   * 전체 히스토리 삭제
   * @returns {Promise<Object>} { deletedCount }
   */
  async clearHistory() {
    if (!this.jwtToken) {
      throw new Error('Not authenticated');
    }

    try {
      const response = await fetch(`${BACKEND_URL}/api/notes/history`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${this.jwtToken}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.status === 401) {
        await this.logout();
        throw new Error('Session expired. Please login again.');
      }

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to clear history');
      }

      const data = await response.json();
      return data.data;

    } catch (error) {
      console.error('Clear history failed:', error);
      throw error;
    }
  }

  /**
   * 인증 상태 확인
   * @returns {boolean}
   */
  isAuthenticated() {
    return !!this.jwtToken;
  }

  /**
   * 현재 사용자 정보
   * @returns {Object|null}
   */
  getCurrentUser() {
    return this.user;
  }
}
