/**
 * 로컬 개발 환경 설정
 * 이 파일은 Git에 커밋되지 않습니다 (.gitignore에 추가됨)
 */

// n8n Webhook URL (개발용)
export const WEBHOOK_URL = "http://140.245.112.1:5678/webhook/bridge-notes";

// 개발 모드 설정
export const DEV_MODE = true;

// 기타 개발 환경 설정
export const CONFIG = {
  timeout: 300000, // 5분
  maxRetries: 3,
  logLevel: 'debug'
};
